package com.edu.up.Cliente.clienterestcompleto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteRestCompletoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteRestCompletoApplication.class, args);
	}
}
